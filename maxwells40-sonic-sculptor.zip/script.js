document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const audioUpload = document.getElementById('audioUpload');
    const fileName = document.getElementById('fileName');
    const audioPlayer = document.getElementById('audioPlayer');
    const audioPlayerContainer = document.getElementById('audioPlayerContainer');
    const playBtn = document.getElementById('playBtn');
    const processBtn = document.getElementById('processBtn');
    const downloadBtn = document.getElementById('downloadBtn');
    const pitchControl = document.getElementById('pitchControl');
    const pitchValue = document.getElementById('pitchValue');
    const speedControl = document.getElementById('speedControl');
    const speedValue = document.getElementById('speedValue');
    const advancedToggle = document.getElementById('advancedToggle');
    const advancedOptions = document.getElementById('advancedOptions');
    const reverseAudio = document.getElementById('reverseAudio');
    const echoEffect = document.getElementById('echoEffect');
    
    let audioContext;
    let audioBuffer;
    let modifiedAudioBuffer;
    let isPlaying = false;
    let audioSource;
    
    // Initialize audio context
    function initAudioContext() {
        if (!audioContext) {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
    }
    
    // File upload handler
    audioUpload.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        fileName.textContent = `Selected: ${file.name}`;
        fileName.classList.remove('hidden');
        
        const fileURL = URL.createObjectURL(file);
        audioPlayer.src = fileURL;
        audioPlayerContainer.classList.remove('hidden');
        
        // Enable buttons
        playBtn.disabled = false;
        processBtn.disabled = false;
        
        // Load audio file into buffer
        const reader = new FileReader();
        reader.onload = function(e) {
            initAudioContext();
            audioContext.decodeAudioData(e.target.result)
                .then(buffer => {
                    audioBuffer = buffer;
                    console.log('Audio loaded successfully');
                })
                .catch(err => {
                    console.error('Error decoding audio data', err);
                });
        };
        reader.readAsArrayBuffer(file);
    });
    
    // Play button handler
    playBtn.addEventListener('click', function() {
        if (!audioBuffer) return;
        
        if (isPlaying) {
            stopAudio();
            playBtn.innerHTML = '<i data-feather="play" class="mr-2 inline"></i> Play';
            feather.replace();
        } else {
            playAudio();
            playBtn.innerHTML = '<i data-feather="pause" class="mr-2 inline"></i> Pause';
            feather.replace();
        }
        isPlaying = !isPlaying;
    });
    
    // Process button handler
    processBtn.addEventListener('click', function() {
        if (!audioBuffer) return;
        
        processBtn.disabled = true;
        processBtn.innerHTML = '<i data-feather="loader" class="mr-2 inline processing"></i> Processing';
        feather.replace();
        
        // Process audio with current settings
        processAudio();
    });
    
    // Download button handler
    downloadBtn.addEventListener('click', function() {
        if (!modifiedAudioBuffer) {
            alert('Please process the audio first!');
            return;
        }
        
        downloadAudio();
    });
    // Pitch control handler
    pitchControl.addEventListener('input', function() {
        pitchValue.textContent = parseFloat(this.value).toFixed(1);
    });
// Speed control handler
    speedControl.addEventListener('input', function() {
        speedValue.textContent = `${this.value}x`;
    });
    
    // Advanced options toggle
    advancedToggle.addEventListener('click', function() {
        advancedOptions.classList.toggle('hidden');
        const icon = this.querySelector('i');
        if (advancedOptions.classList.contains('hidden')) {
            icon.setAttribute('data-feather', 'chevron-down');
        } else {
            icon.setAttribute('data-feather', 'chevron-up');
        }
        feather.replace();
    });
    
    // Audio playback functions
    function playAudio() {
        initAudioContext();
        stopAudio();
        
        audioSource = audioContext.createBufferSource();
        audioSource.buffer = modifiedAudioBuffer || audioBuffer;
        audioSource.connect(audioContext.destination);
        audioSource.start();
        
        // Handle when audio ends
        audioSource.onended = function() {
            isPlaying = false;
            playBtn.innerHTML = '<i data-feather="play" class="mr-2 inline"></i> Play';
            feather.replace();
        };
    }
    
    function stopAudio() {
        if (audioSource) {
            audioSource.stop();
            audioSource.disconnect();
        }
    }
    
    // Audio processing functions
    function processAudio() {
        initAudioContext();
        
        // Use the Web Audio API to modify the audio
        const offlineContext = new OfflineAudioContext(
            audioBuffer.numberOfChannels,
            audioBuffer.length,
            audioBuffer.sampleRate
        );
        
        const source = offlineContext.createBufferSource();
        source.buffer = audioBuffer;
        // Apply pitch shift (using playbackRate)
        const pitchValue = parseFloat(pitchControl.value);
        const semitoneRatio = Math.pow(2, pitchValue / 12);
// Apply speed change
        const speedValue = parseFloat(speedControl.value);
        
        source.playbackRate.value = speedValue * semitoneRatio;
        
        // Apply effects if selected
        let lastNode = source;
        
        if (reverseAudio.checked) {
            // Reverse audio
            const reverseNode = offlineContext.createScriptProcessor(4096, 1, 1);
            reverseNode.onaudioprocess = function(e) {
                const input = e.inputBuffer.getChannelData(0);
                const output = e.outputBuffer.getChannelData(0);
                for (let i = 0; i < input.length; i++) {
                    output[i] = input[input.length - i - 1];
                }
            };
            lastNode.connect(reverseNode);
            lastNode = reverseNode;
        }
        
        if (echoEffect.checked) {
            // Echo effect
            const delay = offlineContext.createDelay(2.0);
            delay.delayTime.value = 0.5;
            const feedback = offlineContext.createGain();
            feedback.gain.value = 0.6;
            
            lastNode.connect(delay);
            delay.connect(feedback);
            feedback.connect(delay);
            delay.connect(offlineContext.destination);
        }
        
        lastNode.connect(offlineContext.destination);
        source.start();
        
        offlineContext.startRendering().then(function(renderedBuffer) {
            modifiedAudioBuffer = renderedBuffer;
            console.log('Audio processing complete');
            
            // Update UI
            processBtn.disabled = false;
            processBtn.innerHTML = '<i data-feather="refresh-cw" class="mr-2 inline"></i> Process';
            downloadBtn.disabled = false;
            feather.replace();
            
            // Play the processed audio if currently playing
            if (isPlaying) {
                stopAudio();
                playAudio();
            }
        }).catch(function(err) {
            console.error('Rendering failed:', err);
            
            // Reset UI on error
            processBtn.disabled = false;
            processBtn.innerHTML = '<i data-feather="refresh-cw" class="mr-2 inline"></i> Process';
            feather.replace();
        });
    }
    
    // Audio download function
    function downloadAudio() {
        if (!modifiedAudioBuffer) return;
        
        // Convert buffer to WAV
        const audioData = bufferToWav(modifiedAudioBuffer);
        const blob = new Blob([audioData], { type: 'audio/wav' });
        const url = URL.createObjectURL(blob);
        
        // Create download link
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `modified_${audioUpload.files[0].name.split('.')[0]}.wav`;
        document.body.appendChild(a);
        a.click();
        
        // Clean up
        setTimeout(function() {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }, 100);
    }
    
    // Helper function to convert buffer to WAV
    function bufferToWav(buffer) {
        const numOfChan = buffer.numberOfChannels;
        const length = buffer.length * numOfChan * 2 + 44;
        const bufferArray = new ArrayBuffer(length);
        const view = new DataView(bufferArray);
        
        // Write WAV header
        writeString(view, 0, 'RIFF');
        view.setUint32(4, 36 + buffer.length * numOfChan * 2, true);
        writeString(view, 8, 'WAVE');
        writeString(view, 12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true);
        view.setUint16(22, numOfChan, true);
        view.setUint32(24, buffer.sampleRate, true);
        view.setUint32(28, buffer.sampleRate * 2 * numOfChan, true);
        view.setUint16(32, numOfChan * 2, true);
        view.setUint16(34, 16, true);
        writeString(view, 36, 'data');
        view.setUint32(40, buffer.length * numOfChan * 2, true);
        
        // Write the PCM samples
        let offset = 44;
        for (let i = 0; i < buffer.numberOfChannels; i++) {
            const channel = buffer.getChannelData(i);
            for (let j = 0; j < channel.length; j++) {
                const sample = Math.max(-1, Math.min(1, channel[j]));
                view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7FFF, true);
                offset += 2;
            }
        }
        
        return bufferArray;
    }
    
    function writeString(view, offset, string) {
        for (let i = 0; i < string.length; i++) {
            view.setUint8(offset + i, string.charCodeAt(i));
        }
    }
    
    // Initialize feather icons
    feather.replace();
});